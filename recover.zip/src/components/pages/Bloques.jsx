import React from 'react'

const Bloques = () => {
    return (
        <div>
            <section class="par nopdb">
				<div class="container">
					<div class="paginas">
						<div class="row">
							<div class="col-12">
								<div class="titulo nomg especial">
									<h2>Lorem ipsum dolor sit amet, consectetur adipisicing.</h2>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-12">
								<div class="destacados">
									<div class="row gutter">
										<div class="col-12 col-lg-4">
											<div class="modulo">
												<h3>Lorem ipsum dolor sit amet</h3>
												<p>Ante cualquier accidente <strong>dirígete a la Urgencia de la Clínica/hospital que prefieras, ya sea por ubicación/calidad/confianza/etc. y simplemente te atiendes.</strong> Al momento de hacer el pago, lo que no está cubierto por Isapre/Fonasa o por otros seguros.</p>
											</div>
										</div>
										<div class="col-12 col-lg-4">
											<div class="modulo">
												<h3>Lorem ipsum dolor sit amet</h3>
												<p>Ante cualquier accidente <strong>dirígete a la Urgencia de la Clínica/hospital que prefieras, ya sea por ubicación/calidad/confianza/etc. y simplemente te atiendes.</strong> Al momento de hacer el pago, lo que no está cubierto por Isapre/Fonasa o por otros seguros.</p>
											</div>
										</div>
										<div class="col-12 col-lg-4">
											<div class="modulo">
												<h3>Lorem ipsum dolor sit amet</h3>
												<p>Ante cualquier accidente <strong>dirígete a la Urgencia de la Clínica/hospital que prefieras, ya sea por ubicación/calidad/confianza/etc. y simplemente te atiendes.</strong> Al momento de hacer el pago, lo que no está cubierto por Isapre/Fonasa o por otros seguros.</p>
											</div>
										</div>
										<div class="col-12 col-lg-4">
											<div class="modulo">
												<h3>Lorem ipsum dolor sit amet</h3>
												<p>Ante cualquier accidente <strong>dirígete a la Urgencia de la Clínica/hospital que prefieras, ya sea por ubicación/calidad/confianza/etc. y simplemente te atiendes.</strong> Al momento de hacer el pago, lo que no está cubierto por Isapre/Fonasa o por otros seguros.</p>
											</div>
										</div>
										<div class="col-12 col-lg-4">
											<div class="modulo">
												<h3>Lorem ipsum dolor sit amet</h3>
												<p>Ante cualquier accidente <strong>dirígete a la Urgencia de la Clínica/hospital que prefieras, ya sea por ubicación/calidad/confianza/etc. y simplemente te atiendes.</strong> Al momento de hacer el pago, lo que no está cubierto por Isapre/Fonasa o por otros seguros.</p>
											</div>
										</div>
										<div class="col-12 col-lg-4">
											<div class="modulo">
												<h3>Lorem ipsum dolor sit amet</h3>
												<p>Ante cualquier accidente <strong>dirígete a la Urgencia de la Clínica/hospital que prefieras, ya sea por ubicación/calidad/confianza/etc. y simplemente te atiendes.</strong> Al momento de hacer el pago, lo que no está cubierto por Isapre/Fonasa o por otros seguros.</p>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
        </div>
    )
}

export default Bloques
